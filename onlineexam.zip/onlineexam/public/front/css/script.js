
setInterval("my_function();",1000);

function my_function(){
    $('#product').load(document.URL +  ' #product');
    $('#title_reload').load(document.URL +  ' #title_reload');
    $('#account_balance').load(document.URL +  ' #account_balance');
    $('#new_account').load(document.URL +  ' #new_account');
}



