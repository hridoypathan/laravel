<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'CreateUserController@loginPage')->name('/');
Route::get('/index', 'CreateUserController@Index')->name('index');
Route::post('/user-logout', 'CreateUserController@userLogout')->name('user-logout');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('admin.master');
Route::post('/user-login', 'CreateUserController@userLogin')->name('user-login');

Route::get('/add-user', 'CreateUserController@addUser')->name('add-user');
Route::post('/save-user', 'CreateUserController@saveUser')->name('save-user');
Route::get('/manage-user', 'CreateUserController@ManageUser')->name('manage-user');
Route::get('/edit-user/{id}', 'CreateUserController@editUser')->name('edit-user');
Route::post('/update-user', 'CreateUserController@updateUser')->name('update-user');
Route::get('/delete-user', 'CreateUserController@deleteUser')->name('delete-user');



Route::get('/add-exam', 'ExamController@addExam')->name('add-exam');
Route::post('/save-exam', 'ExamController@saveExam')->name('save-exam');
Route::get('/manage-exam', 'ExamController@manageExam')->name('manage-exam');
Route::get('/edit-exam/{id}', 'ExamController@editExam')->name('edit.exam');
Route::post('/update-exam', 'ExamController@updateExam')->name('update.exam');
Route::get('/delete-exam', 'ExamController@deleteExam')->name('delete.exam');


Route::get('/add-question', 'QuestionController@addQuestion')->name('add-question');
Route::post('/save-question', 'QuestionController@saveQuestion')->name('save.question');
Route::get('/manage-question', 'QuestionController@manageQuestion')->name('manage-question');
Route::get('/edit-question/{id}', 'QuestionController@editQuestion')->name('edit-question');
Route::post('/update-question', 'QuestionController@updateQuestion')->name('update-question');
Route::get('/delete-question', 'QuestionController@updateQuestion')->name('delete-question');


Route::get('/view-message', 'MessageController@viewMessage')->name('view-message');
Route::get('/manage-message', 'MessageController@manageMessage')->name('manage-message');
Route::get('/reply-message/{id}', 'MessageController@replyMessage')->name('reply-message');
Route::post('/sent-message', 'MessageController@sentMessage')->name('sent-message');
Route::get('/delete-message', 'MessageController@deleteMessage')->name('delete-message');




//front

Route::get('/exam', 'ExamController@Exam')->name('exam');
Route::get('/exam-view/{id}', 'QuestionController@examView')->name('exam-view');

Route::get('/view-usermessage', 'MessageController@viewUserMessage')->name('view-usermessage');
Route::post('/sent-usermessage', 'MessageController@sentUserMessage')->name('sent-usermessage');
Route::get('/view-reply/{id}', 'MessageController@viewReply')->name('view-reply');
//Route::get('/view-reply{user_id}', 'MessageController@UserViewReply')->name('userView-reply');









