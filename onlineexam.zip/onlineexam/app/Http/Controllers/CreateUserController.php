<?php

namespace App\Http\Controllers;

use App\Account;
use App\CreateUser;
use http\Client\Curl\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Session;

class CreateUserController extends Controller
{
    public function addUser(){
        return view('admin.user.add-user');
    }

public function saveUser(Request $request){
        $request->validate([
            'name'=>'required',
            'email'=>'required',
            'phone'=>'required',
            'password'=>'required',

        ]);
        $user = new CreateUser();
        $user->name     = $request->name;
        $user->email    = $request->email;
        $user->phone    = $request->phone;
        $user->password = Hash::make($request->password);
        $user->save();
       return back()->with('message','User add successfull');

}


    public function ManageUser(){

        return view('admin.user.manage-user',[
            'users' =>CreateUser::orderby('id','desc')->get(),
        ]);
    }

    public function editUser($id){
        return view('admin.user.edit-user',[
        'user'=>CreateUser::find($id)
        ]);

    }

    public function updateUser(Request $request){
        $user = CreateUser::find($request->id);

        $user->name     = $request->name;
        $user->email    = $request->email;
        $user->phone    = $request->phone;

        $user->save();
        return redirect('/manage-user')->with('message', 'User Update Successful');


    }

    public function deleteUser(Request $request){
        $user= CreateUser::find($request->id);
        $user->delete();
        return back()->with('message','deleted');

    }
    public function loginPage(){
        return view('front.login.login');
    }
    public function Index(){
        return view('front.home.home');
    }

    public function userLogin(Request $request){
        $account = CreateUser::where('email', $request->email)->first();

        if ($account){
            if (password_verify($request->password, $account->password)) {
                Session::put('user_id', $account->id);
                Session::put('email', $account->email);
                Session::put('password', $account->password);
                return redirect('/index');
            } else {
                return redirect('/')->with('message', 'Invalid Password !!!');
            }
        } else {
            return redirect('/')->with('message', 'Invalid Email !!!');
        }
    }

    public function userLogout(Request $request){
        Session::forget('user_id');
        Session::forget('email');
        Session::forget('password');

        return redirect('/');
    }

}
