<?php

namespace App\Http\Controllers;

use App\Exam;
use Illuminate\Http\Request;

class ExamController extends Controller
{
    public function addExam(){
        return view('admin.exam.add-exam');
    }

    public function saveExam(Request $request){
        $request->validate([
            'name' => 'required',
        ]);
        $exam = new Exam();
        $exam->name = $request->name;
        $exam->save();
        return back()->with('message', 'Category Save Successful');
    }

    public function manageExam(){
        return view('admin.exam.manage-exam',[
            'categories' => Exam::orderBy('id', 'desc')->get()
        ]);
    }

    public function editExam($id){
        return view('admin.exam.edit-exam',[
            'exam' => Exam::find($id)
        ]);
    }

    public function updateExam(Request $request){
        $exam = Exam::find($request->id);
        $exam->name = $request->name;
        $exam->save();
        return redirect('/manage-exam')->with('message', 'Category Update Successful');
    }

    public function deleteExam(Request $request){
        $exam = Exam::find($request->id);
        $exam->delete();
        return back()->with('message','deleted');
    }
    public function Exam(){
        return view('front.exam.exam',[
            'categories' => Exam::orderBy('id', 'desc')->get()
        ]);
    }
}
