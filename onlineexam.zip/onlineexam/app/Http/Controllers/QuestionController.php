<?php

namespace App\Http\Controllers;

use App\Exam;
use DB;
use App\Question;
use Illuminate\Http\Request;

class QuestionController extends Controller
{
    public function addQuestion(){
        return view('admin.question.add-question',[
            'categories' => Exam::all()
        ]);
    }

    public function saveQuestion(Request $request){
        $request->validate([
            'category_id' => 'required',
            'question' => 'required',


        ]);

        $question = new Question();
        $question->category_id = $request->category_id;
        $question->question_no = $request->question_no;
        $question->question = $request->question;
        $question->a = $request->a;
        $question->b = $request->b;
        $question->c = $request->c;
        $question->d = $request->d;
        $question->save();
        return back()->with('message', 'Question Save Successful');
    }

    public function manageQuestion(){
        $categories = DB::table('questions')
            ->join('exams', 'questions.category_id', '=', 'exams.id')
            ->select('questions.*', 'exams.name')
            ->get();
        return view('admin.question.manage-question',[
            'questions' => $categories
        ]);
    }
  public function editQuestion($id)
  {
      return view('admin.question.edit-question',[
       'categories' =>Exam::get(),
      'question'=>Question::find($id)
      ]);

  }


    public function updateQuestion(Request $request){
        $question = Question::find($request->id);


        $question->category_id = $request->category_id;
        $question->question_no = $request->question_no;
        $question->question = $request->question;
        $question->a = $request->a;
        $question->b = $request->b;
        $question->c = $request->c;
        $question->d = $request->d;
        $question->save();
        return redirect('/manage-question')->with('message', 'question Update Successful');
    }

    public function deleteQuestion(Request $request){
        $question = Question::find($request->id);
        $question->delete();
        return back()->with('message','deleted');
    }

    public function examView($id){
        $categories = DB::table('questions')
            ->join('exams', 'questions.category_id', '=', 'exams.id')
            ->select('questions.*', 'exams.name')
            ->where('category_id', $id)
            ->get();
        return view('front.exam.question-view',[
            'questions' => $categories
        ]);
    }
}
