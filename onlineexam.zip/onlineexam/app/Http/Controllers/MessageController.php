<?php

namespace App\Http\Controllers;

use App\CreateUser;
use App\Exam;
use App\Message;
use Illuminate\Http\Request;
use DB;
use Session;

class MessageController extends Controller
{
    public function manageMessage()
    {
        return view('admin.message.manage-message',
        ['messages' => Message::orderBy('id', 'desc')->get()]);

    }
    public function replyMessage($id){
        return view('admin.message.reply-message',[
            'message' => Message::find($id)
      ]);
    }

 public function sentMessage(Request $request){
        $message = Message::find($request->id);

        //$message->complain = $request->complain;
        $message->reply = $request->reply;
        $message->save();
     return redirect('/manage-message')->with('message', 'Reply Successful');

 }

 public function deleteMessage(Request $request){
     $message =Message::find($request->id);
     $message->delete();
     return redirect('/manage-message')->with('message', 'Message Deleted Successful');

 }


    public function sentUserMessage(Request $request)
    {
        $message = new Message();
        $message->complain = $request->complain;
        $message->user_id = $request->user_id;
        $message->save();
        return back()->with('message', 'Send Complain Successful');


    }
    public function viewUserMessage(Request $request)
    {
      return view('front.message.view-usermessage');
    }

    public function replyUserMessage($id){
        return view('front.message.reply-message',[
            'message' => Message::find($id)
        ]);
    }
    public function viewReply($id){

        $users = DB::table('messages')
            ->where('user_id' , '=' , Session::get('user_id'))
            ->get();
        return view('front.message.reply-view',[
            'usermessages' => $users
        ]);
    }
}
