<?php

namespace App;

use App\Http\Controllers\CreateUserController;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;

class CreateUser extends Model
{
    public static function saveUserInfo($request){
        $saveUser           = new CreateUser();
        $saveUser->name     = $request->name;
        $saveUser->email    = $request->email;
        $saveUser->phone    = $request->phone;
        $saveUser->password = Hash::make($request->password);
        $saveUser->save();
    }
}
