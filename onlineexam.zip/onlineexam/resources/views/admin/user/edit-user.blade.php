@extends('admin.master')
@section('body')
    <div class="row">
        <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="mb-0">Edit User</h4>
                            <h3 class="text-center text-success">{{ Session::get('message') }}</h3>
                        </div>
                        <div class="card-body">
                            <form class="needs-validation" action="{{route('update-user')}}" method="post" novalidate="">
                                @csrf
                                <input type="hidden" name="id" value="{{ $user->id }}">

                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label for="name">First name</label>
                                        <input type="text" class="form-control" name="name" id="name"  value="{{$user->name}}" >
                                        <div class="invalid-feedback">
                                            Valid Name is required.
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" name="email" value="{{$user->email}}" >
                                    <div class="invalid-feedback">
                                        Please enter a valid email address.
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="phone">Phone</label>
                                    <input type="number" class="form-control" name="phone" value="{{$user->phone}}">
                                    <div class="invalid-feedback">
                                        Please enter a valid email address.
                                    </div>
                                </div>

                                <hr class="mb-4">
                                <button class="btn btn-primary btn-lg btn-block" type="submit">Update</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection
