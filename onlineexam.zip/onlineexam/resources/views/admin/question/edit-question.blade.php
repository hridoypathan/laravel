@extends('admin.master')
@section('body')
    <div class="row">
        <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="row">
                <div class="col-md-10">
                    <div class="card">

                        <div class="card-header">
                            <h4 class="mb-0">Edit Question</h4>
                            <h3 class="text-center text-success">{{ Session::get('message') }}</h3>
                        </div>
                        <div class="card-body">
                            <form class="needs-validation" action="{{route('update-question')}}" method="post" novalidate="">
                                @csrf
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label for="name">Category</label>
                                        <select class="form-control">
                                            @foreach($categories as $category)
                                            <option value="{{$category->category_id}}">{{$category->name}}</option>
                                             @endforeach
                                        </select>
{{--                                        <input type="text" class="form-control" name="category_id"  value="{{$question->category_id}}" required="">--}}



                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="name">Question Number</label>
                                        <input type="text" class="form-control" name="question_no"  value="{{$question->question_no}}" required="">
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="name">Question</label>
                                        <input type="text" class="form-control" name="question"  value="{{$question->question}}" required="">
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="name">A</label>
                                        <input type="text" class="form-control" name="a"  value="{{$question->a}}" required="">
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="name">B</label>
                                        <input type="text" class="form-control" name="b"  value="{{$question->b}}" required="">
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="name">C</label>
                                        <input type="text" class="form-control" name="c"  value="{{$question->c}}" required="">
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="name">D</label>
                                        <input type="text" class="form-control" name="d"  value="{{$question->d}}" required="">
                                    </div>

                                    <input type="hidden" name="id" value="{{ $question->id }}">
                                </div>

                                <hr class="mb-4">
                                <button class="btn btn-primary btn-lg btn-block" type="submit">Update</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection
