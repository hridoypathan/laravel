@extends('admin.master')
@section('body')
    <div class="row">
        <!-- ============================================================== -->
        <!-- basic table  -->
        <!-- ============================================================== -->
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Manage Question</h5>
                <h2 class="text-success text-center">{{ Session::get('message') }}</h2>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered first">
                            <thead>
                            <tr>
                                <th>SL No.</th>
                                <th>Category Name</th>
                                <th>Question No.</th>
                                <th>Question</th>
                                <th>A</th>
                                <th>B</th>
                                <th>C</th>
                                <th>D</th>
                                <th>Action</th>
                            </tr>
                            </thead>

                            @php($i=1)
                            @foreach($questions as $question)
                                <tbody>
                                <td>{{ $i++ }}</td>
                                <td>{{ $question->name }}</td>
                                <td>{{ $question->question_no }}</td>
                                <td>{{ $question->question }}</td>
                                <td>{{ $question->a }}</td>
                                <td>{{ $question->b }}</td>
                                <td>{{ $question->c }}</td>
                                <td>{{ $question->d }}</td>
                                 <td>

                                     <a class="btn btn-success" href="{{route('edit-question', ['id' =>$question->id]) }}">Edit</a>
                                     <a class="btn btn-danger" href="{{route('delete-question',['id'=>$question->id])}}">Delete</a>
                                 </td>
                                </tbody>
                            @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
