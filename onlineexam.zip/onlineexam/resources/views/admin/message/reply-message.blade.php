@extends('admin.master')
@section('body')
    <div class="row">
        <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="mb-0">Replay Message</h4>

                        </div>
                        <h2 class="text-center text-success">{{ Session::get('message') }}</h2>
                        <div class="card-body">
                            <form class="needs-validation" action="{{route('sent-message')}}" method="post" novalidate="">
                                @csrf
                                <input type="hidden" name="id" value="{{$message->id}}">

                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label for="name">Complain</label>
                                        <input type="text"  class="form-control" name="name" id="name"  value="{{$message->complain}}" >
                                        <div class="invalid-feedback">

                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label >Reply</label>
                                    <input type="text" class="form-control" name="reply" value="" >
                                    <div class="invalid-feedback">
                                        Please enter a valid email address.
                                    </div>
                                </div>


                                <hr class="mb-4">
                                <button class="btn btn-primary btn-lg btn-block" type="submit">Sent</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection
