@extends('admin.master')
@section('body')
    <div class="row">
        <!-- ============================================================== -->
        <!-- basic table  -->
        <!-- ============================================================== -->
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Manage Message</h5>
                <h2 class="text-success text-center">{{ Session::get('message') }}</h2>
                <div class="card-body">


                       <div class="table-responsive">
                           <table class="table table-striped table-bordered first">
                               <thead>
                               <tr>
                                   <th>SL No.</th>
                                   <th>User Id</th>

                                   <th>Complain</th>
                                   <th>Replay</th>

                                   <th>Action</th>
                               </tr>
                               </thead>


                               @php $i=1; @endphp
                               @foreach($messages as $message)
                                   <tbody>
                                   <td>{{$i++}}</td>
                                   <td>{{$message->user_id}}</td>
                                   <td>{{$message->complain}}</td>
                                   <td>{{$message->reply}}</td>
                                   <td>

                                       <a class="btn btn-success" href="{{ route('reply-message',['id' => $message->id]) }}">Reply</a>
                                       <a class="btn btn-danger" href="{{ route('delete-message',['id' => $message->id]) }}">Delete</a>


                                       @csrf


                                   </td>

                               </tbody>
                               @endforeach
                           </table>
                       </div>
                </div>


            </div>
        </div>
    </div>
@endsection
