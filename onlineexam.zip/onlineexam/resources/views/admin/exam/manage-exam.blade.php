@extends('admin.master')
@section('body')
    <div class="row">
        <!-- ============================================================== -->
        <!-- basic table  -->
        <!-- ============================================================== -->
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Manage User</h5>
                <h2 class="text-success text-center">{{ Session::get('message') }}</h2>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered first">
                            <thead>
                            <tr>
                                <th>SL No.</th>
                                <th>Category Id.</th>

                                <th>Exam Name</th>
                                <th>Action</th>
                            </tr>
                            </thead>

                            @php($i=1)
                            @foreach($categories as $category)
                            <tbody>
                            <td>{{ $i++ }}</td>
                            <td>{{ $category->id }}</td>
                            <td>{{ $category->name }}</td>
                            <td>
                                <a class="btn btn-success" href="{{ route('edit.exam',['id' => $category->id]) }}">Edit</a>
                                <a class="btn btn-danger" href="{{ route('delete.exam',['id' => $category->id]) }}" >Delete</a>



                            </td>
                            </tbody>
                            @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
