@extends('admin.master')
@section('body')
    <div class="row">
        <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="mb-0">Edit Exam Category</h4>

                        </div>
                        <h2 class="text-center text-success">{{ Session::get('message') }}</h2>
                        <div class="card-body">
                            <form class="needs-validation" action="{{route('update.exam')}}" method="post" novalidate="">
                                @csrf
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label for="ädd_exam">Update Exam Category</label>
                                        <input type="text" class="form-control" name="name" placeholder="category" value="{{ $exam->name }}">

                                        <input type="hidden" name="id" value="{{ $exam->id }}">

                                        <div class="invalid-feedback">
                                            Valid Name is required.
                                        </div>
                                    </div>
                                </div>

                                <hr class="mb-4">
                                <button class="btn btn-primary btn-lg btn-block" type="submit">Save</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection
