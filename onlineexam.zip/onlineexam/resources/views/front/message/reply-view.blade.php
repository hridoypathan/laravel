@extends('front.master')
@section('body')
    <div class="row">
        <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="mb-0">Replay Message</h4>

                        </div>

                        <div class="card-body border-3">

                            <table class="table table-bordered text-left w-100">
                                <tr>
                                    <th>Complain</th>
                                    <th>Reply</th>
                                </tr>
                                @foreach($usermessages as $usermessage)
                                <tr>
                                    <td class="w-50">
                                        {{ $usermessage->complain }}
                                    </td>
                                    <td class="w-50">
                                        <p>{{ $usermessage->reply }}</p>
                                    </td>
                                </tr>
                                @endforeach
                            </table>

{{--                            @foreach($usermessages as $usermessage)--}}
{{--                            <h6>{{ $usermessage->complain }}</h6>--}}
{{--                            <hr>--}}
{{--                            <p>{{ $usermessage->reply }}</p>--}}
{{--                            @endforeach--}}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection
