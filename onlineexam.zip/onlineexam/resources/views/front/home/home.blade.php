@extends('front.master')
@section('body')

 @endsection
