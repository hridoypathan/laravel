<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Online Exam</title>
    <link rel="icon" href="{{ asset('/') }}front/images/ab2.jpg">
    <!-- Meta tag Keywords -->
    {{--    <meta http-equiv="refresh" content="10">--}}
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <!-- Custom-Files -->
    <link rel="stylesheet" href="{{ asset('/') }}front/css/bootstrap.css">
    <!-- Bootstrap-Core-CSS -->
    <link href="{{ asset('/') }}front/css/css_slider.css" type="text/css" rel="stylesheet" media="all">
    <!-- banner slider -->
    <link rel="stylesheet" href="{{ asset('/') }}front/css/style.css" type="text/css" media="all" />
    <!-- Style-CSS -->
    <link href="{{ asset('/') }}front/css/font-awesome.min.css" rel="stylesheet">
    <link href="{{ asset('/') }}front/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
<!--Second Menu-->
<div id="home1">
    <!-- header -->
    <div class="">
        <div class="m-auto text-center d-lg-flex justify-content-between">
            <!-- As a link -->
            <div class="scrollmenu navbar-light bg-primary" style="width: 100%">
                <a class="navbar-brand second-nav text-white pl-3 pt-2" href="">Home</a>
                <a class="navbar-brand second-nav text-white pt-2" href="{{ route('exam') }}">Exam</a>
                <a class="navbar-brand second-nav text-white pt-2" href="{{route('view-usermessage')}}">Complain</a>
                <a class="navbar-brand second-nav text-white pt-2" href="">Contact</a>
                @if(Session::get('user_id'))
                    <a href="" class="navbar-brand second-nav text-white pt-2" onclick="
                         event.preventDefault(); document.getElementById('visitorAccountForm').submit();
                         ">Log out</a>
                    <form id="visitorAccountForm" action="{{ route('user-logout') }}" method="POST">
                        @csrf
                    </form>
                @endif

            </div>
        </div>
    </div>
    <!-- //header -->
</div>
@yield('body')



<script src="{{ asset('/') }}front/css/jquery.min.js"></script>
<script src="{{ asset('/') }}front/css/script.js"></script>

</body>

</html>
