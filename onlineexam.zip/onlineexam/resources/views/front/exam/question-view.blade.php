@extends('front.master')
@section('body')
    <div class="row">
        <!-- ============================================================== -->
        <!-- basic table  -->
        <!-- ============================================================== -->
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Question</h5>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered first">
                            <thead>
                            <tr>
                                <th>SL No.</th>
                                <th>Category Name</th>
                                <th>Question No.</th>
                                <th>Question</th>
                                <th>A</th>
                                <th>B</th>
                                <th>C</th>
                                <th>D</th>
                            </tr>
                            </thead>

                            @php($i=1)
                            @foreach($questions as $question)
                                <tbody>
                                <td>{{ $i++ }}</td>
                                <td>{{ $question->name }}</td>
                                <td>{{ $question->question_no }}</td>
                                <td>{{ $question->question }}</td>
                                <td>{{ $question->a }}</td>
                                <td>{{ $question->b }}</td>
                                <td>{{ $question->c }}</td>
                                <td>{{ $question->d }}</td>
                                </tbody>
                            @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
