@extends('front.master')
@section('body')
        <ul class="container text-center mt-5">
            <li style="list-style-type: none;">
                @foreach($categories as $category)
                    <p class="home-info bg-white mb-1" style="border: 1px solid black">
                        <a class="text-primary font-weight-bold" href="{{ route('exam-view', ['id' => $category->id]) }}">{{ $category->name }}</a>
                    </p>
                @endforeach
            </li>
        </ul>

@endsection
