<?php $__env->startSection('body'); ?>
    <div class="row">
        <!-- ============================================================== -->
        <!-- basic table  -->
        <!-- ============================================================== -->
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Manage User</h5>
                <h2 class="text-success text-center"><?php echo e(Session::get('message')); ?></h2>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered first">
                            <thead>
                            <tr>
                                <th>SL No.</th>
                                <th>Category Id.</th>

                                <th>Exam Name</th>
                                <th>Action</th>
                            </tr>
                            </thead>

                            <?php ($i=1); ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($category->id); ?></td>
                            <td><?php echo e($category->name); ?></td>
                            <td>
                                <a class="btn btn-success" href="<?php echo e(route('edit.exam',['id' => $category->id])); ?>">Edit</a>
                                <a class="btn btn-danger" href="<?php echo e(route('delete.exam',['id' => $category->id])); ?>" >Delete</a>



                            </td>
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\onlineexam\resources\views/admin/exam/manage-exam.blade.php ENDPATH**/ ?>