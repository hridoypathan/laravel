<?php $__env->startSection('body'); ?>
    <div class="row">
        <!-- ============================================================== -->
        <!-- basic table  -->
        <!-- ============================================================== -->
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">View Message</h5>
                <h2 class="text-success text-center"><?php echo e(Session::get('message')); ?></h2>
                <div class="card-body">

                    <form class="needs-validation" action="" method="post" novalidate="">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered first">
                                <thead>
                                <tr>
                                    <th>SL No.</th>
                                    <th>Id.</th>
                                    <th>User Id</th>

                                    <th>Complain</th>


                                    <th>Action</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $i=1; ?>
                                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($message->id); ?></td>
                                    <td><?php echo e($message->user_id); ?></td>
                                    <td><?php echo e($message->complain); ?></td>

                                    <td>

                                        <a class="btn btn-success" href="<?php echo e(route('reply-message',['id'=>$message->id])); ?>">Replay</a>

                                        <?php echo csrf_field(); ?>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                </div>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\onlineexam\resources\views/admin/message/view-message.blade.php ENDPATH**/ ?>