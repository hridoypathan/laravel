<?php $__env->startSection('body'); ?>
    <div class="row">
        <!-- ============================================================== -->
        <!-- basic table  -->
        <!-- ============================================================== -->
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Manage Message</h5>
                <h2 class="text-success text-center"><?php echo e(Session::get('message')); ?></h2>
                <div class="card-body">


                       <div class="table-responsive">
                           <table class="table table-striped table-bordered first">
                               <thead>
                               <tr>
                                   <th>SL No.</th>
                                   <th>User Id</th>

                                   <th>Complain</th>
                                   <th>Replay</th>

                                   <th>Action</th>
                               </tr>
                               </thead>


                               <?php $i=1; ?>
                               <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tbody>
                                   <td><?php echo e($i++); ?></td>
                                   <td><?php echo e($message->user_id); ?></td>
                                   <td><?php echo e($message->complain); ?></td>
                                   <td><?php echo e($message->reply); ?></td>
                                   <td>

                                       <a class="btn btn-success" href="<?php echo e(route('reply-message',['id' => $message->id])); ?>">Reply</a>
                                       <a class="btn btn-danger" href="<?php echo e(route('delete-message',['id' => $message->id])); ?>">Delete</a>


                                       <?php echo csrf_field(); ?>


                                   </td>

                               </tbody>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </table>
                       </div>
                </div>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\onlineexam\resources\views/admin/message/manage-message.blade.php ENDPATH**/ ?>