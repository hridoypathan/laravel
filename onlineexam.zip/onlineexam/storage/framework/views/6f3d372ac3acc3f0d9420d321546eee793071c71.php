<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="mb-0">Edit Exam Category</h4>

                        </div>
                        <h2 class="text-center text-success"><?php echo e(Session::get('message')); ?></h2>
                        <div class="card-body">
                            <form class="needs-validation" action="<?php echo e(route('update.exam')); ?>" method="post" novalidate="">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label for="ädd_exam">Update Exam Category</label>
                                        <input type="text" class="form-control" name="name" placeholder="category" value="<?php echo e($exam->name); ?>">

                                        <input type="hidden" name="id" value="<?php echo e($exam->id); ?>">

                                        <div class="invalid-feedback">
                                            Valid Name is required.
                                        </div>
                                    </div>
                                </div>

                                <hr class="mb-4">
                                <button class="btn btn-primary btn-lg btn-block" type="submit">Save</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\onlineexam\resources\views/admin/exam/edit-exam.blade.php ENDPATH**/ ?>