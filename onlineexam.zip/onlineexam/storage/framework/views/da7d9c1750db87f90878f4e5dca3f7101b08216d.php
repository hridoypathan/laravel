<?php $__env->startSection('body'); ?>
        <ul class="container text-center mt-5">
            <li style="list-style-type: none;">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="home-info bg-white mb-1" style="border: 1px solid black">
                        <a class="text-primary font-weight-bold" href="<?php echo e(route('exam-view', ['id' => $category->id])); ?>"><?php echo e($category->name); ?></a>
                    </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </li>
        </ul>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\onlineexam\resources\views/front/exam/exam.blade.php ENDPATH**/ ?>