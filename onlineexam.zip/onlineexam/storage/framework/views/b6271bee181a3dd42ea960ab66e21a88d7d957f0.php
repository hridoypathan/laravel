<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="mb-0">complain</h4>
                            <h4 class="text-success text-center"><?php echo e(Session::get('message')); ?></h4>
                        </div>

                        <div class="card-body">

                            <form class="needs-validation" action="<?php echo e(route('sent-usermessage')); ?>" method="post" novalidate="">
                                <?php echo csrf_field(); ?>
                                <input class="form-control d-none" readonly checked name="user_id" value="<?php echo e(Session::get('user_id')); ?>">
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label >Complain</label>
                                        <input type="text" class="form-control" name="complain" placeholder="complain" value="" required="">

                                        <div class="invalid-feedback">
                                            Valid Name is required.
                                        </div>
                                    </div>
                                </div>

                                <hr class="mb-4">
                                <button class="btn btn-primary btn-lg btn-block" type="submit">Sent</button>
                            </form>

                        </div>

                        <div>
                            <a class="btn btn-block btn-info text-white" href="<?php echo e(route('view-reply', ['id' => Session::get('user_id')])); ?>">Veiw Reply</a>
                        </div>


                    </div>

                    <div>

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\onlineexam\resources\views/front/message/view-usermessage.blade.php ENDPATH**/ ?>