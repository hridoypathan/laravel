<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="mb-0">Replay Message</h4>

                        </div>

                        <div class="card-body border-3">

                            <table class="table table-bordered text-left w-100">
                                <tr>
                                    <th>Complain</th>
                                    <th>Reply</th>
                                </tr>
                                <?php $__currentLoopData = $usermessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usermessage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="w-50">
                                        <?php echo e($usermessage->complain); ?>

                                    </td>
                                    <td class="w-50">
                                        <p><?php echo e($usermessage->reply); ?></p>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>






                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\onlineexam\resources\views/front/message/reply-view.blade.php ENDPATH**/ ?>