<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="offset-xl-2 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="row">
                <div class="col-md-10">
                    <div class="card">

                        <div class="card-header">
                            <h4 class="mb-0">Add Question</h4>
                            <h3 class="text-center text-success"><?php echo e(Session::get('message')); ?></h3>
                        </div>
                        <div class="card-body">
                            <form class="needs-validation" action="<?php echo e(route('save.question')); ?>" method="post" novalidate="">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label for="name">Category</label>

                                        <select class="form-control" name="category_id">
                                            <option selected disabled>>-------Select Category-------<</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="name">Question Number</label>
                                        <input type="text" class="form-control" name="question_no" placeholder="Question Number" value="" required="">
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="name">Question</label>
                                        <input type="text" class="form-control" name="question" placeholder="Question" value="" required="">
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="name">A</label>
                                        <input type="text" class="form-control" name="a" placeholder="A" value="" required="">
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="name">B</label>
                                        <input type="text" class="form-control" name="b" placeholder="B" value="" required="">
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="name">C</label>
                                        <input type="text" class="form-control" name="c" placeholder="C" value="" required="">
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="name">D</label>
                                        <input type="text" class="form-control" name="d" placeholder="D" value="" required="">
                                    </div>
                                </div>

                                <hr class="mb-4">
                                <button class="btn btn-primary btn-lg btn-block" type="submit">Save</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\onlineexam\resources\views/admin/question/add-question.blade.php ENDPATH**/ ?>